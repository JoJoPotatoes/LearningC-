#include <iostream>
using namespace std;

int main()
{
	cout << "Good Morning! I'm learning C++!\n";
	cout << "Click ENTER to exit test application...\n";
	cin.get();
	return 0;
}